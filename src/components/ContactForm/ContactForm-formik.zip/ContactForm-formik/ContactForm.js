import PropTypes from 'prop-types';

import { Component } from 'react';
import { nanoid } from 'nanoid';
import { Forma, Input } from 'components/ContactForm/ContactForm.styled';
import { Formik, ErrorMessage } from 'formik';
import * as yup from 'yup';

const schema = yup.object().shape({
  name: yup
    .string()
    .required(
      "Name may contain only letters, apostrophe, dash and spaces. For example Adrian, Jacob Mercer, Charles de Batz de Castelmore d'Artagnan"
    ),
  number: yup
    .number()
    .required(
      'Phone number must be digits and can contain spaces, dashes, parentheses and can start with +'
    )
    .positive(),
});

export class ContactForm extends Component {
  state = {
    name: '',
    number: '',
  };

  nameInputId = nanoid();

  handleSubmit = e => {
    // e.preventDefault();
    // console.log(e.target.elements.name.value);
    this.props.onContact(this.state);
    this.reset();
  };

  handleSubmit1 = (values, actions) => {
    const { resetForm } = actions;
    console.log(values);
    console.log(actions);
    resetForm();
  };

  handleChange = e => {
    const { name, value } = e.currentTarget;
    // console.log(name);
    this.setState({ [name]: value });
  };

  reset = () => {
    this.setState({ name: '', number: '' });
  };

  render() {
    const initialValues = this.state;

    return (
      <Formik
        initialValues={initialValues}
        validationSchema={schema}
        onSubmit={this.handleSubmit1}
      >
        <Forma>
          <div>
            <label htmlFor={this.nameInputId}>Name</label>
            <Input
              id={this.nameInputId}
              // value={this.state.name}
              // onChange={this.handleChange}
              type="text"
              name="name"
              // pattern="^[a-zA-Zа-яА-Я]+(([' -][a-zA-Zа-яА-Я ])?[a-zA-Zа-яА-Я]*)*$"
              // title="Name may contain only letters, apostrophe, dash and spaces. For example Adrian, Jacob Mercer, Charles de Batz de Castelmore d'Artagnan"
              // required
            />
            <ErrorMessage name="name" component="div" />
          </div>

          <div>
            <label htmlFor={this.nameInputId}>Number</label>
            <Input
              id={this.nameInputId}
              // value={this.state.number}
              // onChange={this.handleChange}
              type="tel"
              name="number"
              // pattern="\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}"
              // title="Phone number must be digits and can contain spaces, dashes, parentheses and can start with +"
              // required
            />
            <ErrorMessage name="number" component="div" />
          </div>

          <button type="submit">Add contact</button>
        </Forma>
      </Formik>
    );
  }
}

ContactForm.propTypes = {
  onContact: PropTypes.func.isRequired,
};
